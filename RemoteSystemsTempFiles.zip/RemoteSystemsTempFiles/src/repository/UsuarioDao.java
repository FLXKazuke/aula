package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import connectionFactory.ConnectionFactory;
import model.Usuario;

public class UsuarioDao {

	private Connection conexao;

	public UsuarioDao() {
		this.conexao = new ConnectionFactory().conectar();
	}

	public void insert(Usuario usuario) throws SQLException {
		String sql = "insert into USUARIOS(id, nome, email, telefone, data) values (?,?,?,?,?)";
		PreparedStatement stmt = conexao.prepareStatement(sql);

		stmt.setLong(1, usuario.getId());
		stmt.setString(2, usuario.getNome());
		stmt.setString(3, usuario.getEmail());
		stmt.setInt(4, usuario.getTelefone());
		stmt.setDate(5, usuario.getData());

		stmt.execute();
		stmt.close();
	}

	public List<Usuario> select() throws SQLException {
		List<Usuario> usuarios = new ArrayList<Usuario>();
		String sql = "select * from USUARIOS";
		PreparedStatement stmt = conexao.prepareStatement(sql);
		ResultSet rs = stmt.executeQuery();

		while (rs.next()) {
			Usuario usuario = new Usuario();
			usuario.setId(rs.getLong("ID"));
			usuario.setNome(rs.getString("NOME"));
			usuario.setEmail(rs.getString("EMAIL"));
			usuario.setTelefone(rs.getInt("TELEFONE"));
			usuario.setData(rs.getDate("DATA"));

			usuarios.add(usuario);

		}
		rs.close();
		stmt.close();
		return usuarios;
	}
}