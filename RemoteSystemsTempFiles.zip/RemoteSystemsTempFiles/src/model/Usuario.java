package model;

import java.sql.Date;
import java.util.Calendar;

public class Usuario {

	// atributos
	private long id;
	private String nome;
	private String email;
	private int telefone;
	private Date data;

	public Usuario() {
		this.data = new Date(Calendar.getInstance().getTimeInMillis());
	}

	// m�todos getters / setter
	public long getId() {
		return id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String string) {
		this.nome = string;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getTelefone() {
		return telefone;
	}

	public void setTelefone(int i) {
		this.telefone = i;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public void setId(long long1) {

	}

	public Date getData() {
		return data;
	}


}
