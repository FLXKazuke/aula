package Teste;

import java.sql.SQLException;
import java.util.List;

import model.Usuario;
import repository.UsuarioDao;

public class Teste {

	public static void main(String[] args) throws SQLException {

		UsuarioDao dao = new UsuarioDao();
		Usuario emerson = new Usuario();
		Usuario jorge = new Usuario();

		emerson.setId(1L);
		emerson.setNome("Abraham");
		emerson.setEmail("jsholiveira@gmail.com");
		emerson.setTelefone(213456789);

		jorge.setId(2L);
		jorge.setNome("Jorge");
		jorge.setEmail("Jsholiveira2@gmail.com");
		jorge.setTelefone(234567890);

		dao.insert(jorge);
		dao.insert(emerson);

		List<Usuario> lista = dao.select();

		for (Usuario usuario : lista) {
			System.out.println(usuario.getId());
			System.out.println(usuario.getNome());
			System.out.println(usuario.getEmail());
			System.out.println(usuario.getData());
		}
		
	}

}
